<div id="lc_global_search">
	<div class="lc_global_search_inner">
		<?php get_search_form(); ?>
		
		<div class="close_search_form">
			<i class="fa fa-times"></i>
		</div>
	</div>
</div>