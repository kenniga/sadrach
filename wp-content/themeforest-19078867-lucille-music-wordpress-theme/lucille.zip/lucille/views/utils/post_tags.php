<div class="lc_post_tags tagcloud">
	<?php 
	// $before_tag = '<span class="post_tag">';
	// $after_tag = '</span>';
	//the_tags( $before_tag, ' ', $after_tag);  
	the_tags('', ' ', '');  
	?>
</div>